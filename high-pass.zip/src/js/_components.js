import './components/yandex-map.js';
import './components/script-dev.js';
import './components/valid-form.js';
import './components/contacts-form-tho.js';
