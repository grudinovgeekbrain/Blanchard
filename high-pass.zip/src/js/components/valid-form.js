const validation = new JustValidate('#form');

validation
  .addField('#email', [
    {
      rule: 'minLength',
      value: 3,
    },
    {
      rule: 'maxLength',
      value: 20,
    },
  ])
  .addField('#email', [
    {
      rule: 'required',
      errorMessage: 'Недопустимый формат',
    },
    {
      rule: 'email',
      errorMessage: 'Email is invalid!',
    },
  ])


