// * section header *//

let openBtn = document.querySelector(".header__btn--search")
let btnSubmit = document.querySelector(".header__btn--submit")
let btnclosed = document.querySelector(".header__btn--closed")
let searchLabel = document.querySelector(".header__label")


openBtn.addEventListener("click", () => {
  searchLabel.classList.remove("search-disable")
  openBtn.classList.add("search-disable")
  btnSubmit.classList.add("btn-submit-active")
});

btnSubmit.addEventListener("click", () => {
  btnSubmit.classList.add("search-disable")
  btnclosed.classList.add("btn-submit-active")
});

btnclosed.addEventListener("click", () => {
  searchLabel.classList.toggle('search-disable')
})
