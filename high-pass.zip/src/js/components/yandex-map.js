  // Функция ymaps.ready() будет вызвана, когда
    // загрузятся все компоненты API, а также когда будет готово DOM-дерево.
    ymaps.ready(init);
    function init(){
        // Создание карты.
        var myMap = new ymaps.Map("map", {
            // Координаты центра карты.
            // Порядок по умолчанию: «широта, долгота».
            // Чтобы не определять координаты центра карты вручную,
            // воспользуйтесь инструментом Определение координат.
            center: [55.76, 37.64],
            // Уровень масштабирования. Допустимые значения:
            // от 0 (весь мир) до 19.
            zoom: 7
        });



        var myPlacemark = new ymaps.Placemark([55.769470, 37.639012], {}, {
          iconLayout: 'default#image',
          iconImageHref: '../img/svg/yandex-placemark.svg',
          iconImageSize: [12, 12],
          iconImageOffset: [-3, -42]
      });

          // Размещение геообъекта на карте.
          myMap.geoObjects.add(myPlacemark);


        // Удалим с карты «Ползунок масштаба».
        myMap.controls.remove('zoomControl');
        myMap.controls.remove('searchControl');
        myMap.controls.remove('rulerControl');
        myMap.controls.remove('trafficControl');
        myMap.controls.remove('fullscreenControl');
        myMap.controls.remove('smallMapDefaultSet');
    }




